
import announcements from '../__mock/announcements.json';

const fetchAnnouncements = () => {
    return announcements;
}


export default fetchAnnouncements;