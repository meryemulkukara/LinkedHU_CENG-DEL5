import  React  from 'react'

const DocumentUploader = () => {
    return (
        <div>
            <h1>File Uploader</h1>
        </div>
    )
}

export default DocumentUploader;