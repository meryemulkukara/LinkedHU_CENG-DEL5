import { createContext } from 'react';

const ApplicationContext = createContext();
export { ApplicationContext }